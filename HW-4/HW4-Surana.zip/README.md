# Large Scale Sofware Development Distribution App
### ECE 4574 Fall 2020 (Dhairya Surana)

## Installation

1. Install Qt Creator (any version should work)
2. Download and extract zip file 
3. Open Qt Creator and go to File -> Open File or Project. Select the project directory.
4. Click on the Green Play button 

NOTE: For the sliders, click and drag the bars (Clicking on slider line will not change value)